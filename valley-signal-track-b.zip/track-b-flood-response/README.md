# Valley Signal

**Track B - Mapping Flood Damage from Space**  
Multimodal AI Hackathon 2026

Valley Signal is a small, source-traceable flood mapping desk. Give it an area and event date; it searches public Sentinel scenes, compares same-orbit Sentinel-1 backscatter, requests a pre-event OpenStreetMap snapshot, and estimates which mapped assets and settlements intersect the resulting flood candidates.

The interface is an educational prototype. Its layers are screening evidence for field verification, not a rescue dispatch or evacuation product.

## Run it locally

Requirements: Python 3.10 or later, internet access, and a modern browser. The satellite and historic OSM data are queried at run time; no sample values are presented as observations.

```bash
cd track-b-flood-response
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
python app.py
```

Open <http://127.0.0.1:5055>. The initial area is a sample Trishuli corridor AOI and the event date is 26 August 2026. Edit the bounding box or draw a rectangle on the map, then run an analysis. Satellite searches and OSM extraction can take a few minutes.

## Deploy it

This is a Flask web app with Python API routes, so it needs a Python web-service host; Netlify Drop only publishes static files. See [DEPLOY_RENDER.md](DEPLOY_RENDER.md) for the Render setup. The included `render.yaml` configures the service.

If the ohsome service requires a key for your account, put it in `OHSOME_API_KEY` in your shell or `.env`. The Planetary Computer metadata search is public; data assets are signed automatically by its Python SDK. A `PC_SDK_SUBSCRIPTION_KEY` can be set for higher data-access limits. The v1 ohsome endpoint specified in the challenge is the default. `OHSOME_API_URL` can point to another v1-compatible endpoint.

```bash
export OHSOME_API_KEY="your-key"
python app.py
```

## What the system does

1. **Finds Sentinel-1 scenes.** The STAC search looks up to 36 days on either side of the event date. It pairs scenes with the same relative orbit and pass direction, preferring an interval close to the 12-day repeat cycle. It reports the actual scene dates and gap.
2. **Maps flood candidates.** Sentinel-1 RTC VV backscatter is put on a common 20 m projected grid. A pixel is a candidate when post-event backscatter is below -15 dB and fell by at least 2.5 dB. A Copernicus DEM slope screen removes terrain above 20 degrees when the DEM is available. Small connected patches under six pixels are removed. These are deliberately visible rules, not a trained flood segmentation model.
3. **Adds an optical check when possible.** The closest Sentinel-2 L2A pair within 45 days and at most 35% scene cloud cover is checked with before/after NDWI. The scene classification layer masks cloud, shadow, snow, and invalid classes. The result is a separate corroboration layer; it does not rewrite the radar classification.
4. **Estimates exposed assets.** Roads, bridges, buildings, named settlements, and hospitals are retrieved from the ohsome OSM history API using a timestamp before the event. Asset counts mean geometry intersects a 10 m buffer around flood candidates. They are not confirmed damage counts.
5. **Screens road access.** A graph from the dated OSM road network is evaluated before and after removing road segments that intersect the candidate flood buffer. Settlements are flagged only when they connected to a mapped town or hospital before the removal and no longer connect after it. The graph uses an additional 5 km OSM context margin, while displayed asset counts stay inside the requested AOI.
6. **Writes a fact-bounded situation report.** English and Nepali reports use values computed by the analysis. The question assistant routes common questions to those same stored facts and feature names; it does not call a language model or invent figures. The Export PDF button creates a one-page English report.
7. **Checks the case study reference after analysis.** Upload an EMSR927 flood polygon GeoJSON after a run. The browser calculates polygon intersection-over-union for comparison and draws the reference as a separate layer. Reference geometry is never sent to the analysis endpoint or used to alter the result.

Optional bonus: after a successful analysis with a DEM, click a starting point on the map and run again. The system follows the steepest downhill neighbor on the resampled DEM and lists mapped settlements within 750 m of the line. This terrain-only trace is not a hydrologic flood forecast.

## Sources and rules

- Sentinel-1 RTC, Sentinel-2 L2A, and Copernicus WorldDEM-30 are searched through the [Microsoft Planetary Computer STAC catalog](https://planetarycomputer.microsoft.com/catalog). The Sentinel scenes are Copernicus-derived products. The scene timestamps and identifiers are retained in the result.
- Historic roads, buildings, bridges, settlements, and hospitals come from the challenge's [ohsome API](https://api.ohsome.org/v1). For events after 27 July 2026, Valley Signal fixes the requested OSM snapshot at 27 July 2026, as specified in the brief. Earlier events use the day before the event. The requested snapshot timestamp is shown in the interface and report.
- EMSR927 is a validation reference only. It is not queried, cached, or used by the model.
- No training dataset is used: the selected AI component is the situation-report copilot. Sentinel-based flood candidates are thresholded change detection, not a trained model.
- No contemporary OSM basemap tiles are loaded. The map background is a local coordinate grid; map features come from the date-bounded OSM query and satellite-derived analysis.

## Limits that matter

- Sentinel revisit is measured in days, so this system cannot give minutes-ahead warning of a glacier collapse or sudden flood.
- Radar change can be confused by terrain shadow, steep slopes, vegetation, wet soil, and acquisition conditions. The thresholds are not calibrated against local field labels.
- The model's 20 m output grid is resampled from source imagery. Narrow channels, small structures, and mixed pixels can be missed. The simple threshold is not trained or independently evaluated on unseen Himalayan scenes.
- Sentinel-2 is optical and cloud-limited. Its NDWI layer is only a separate corroboration view and can miss a short-lived flood if the first clear acquisition is late.
- An intersected road, bridge, or building is an exposure estimate. It does not establish that the structure failed. OSM can be incomplete, stale, or geometrically imprecise.
- Connectivity is a topological screen on mapped road centerlines. It does not consider road condition, bridge capacity, traffic, temporary repair, people, or alternative footpaths. The AOI boundary and missing roads can change its result.
- The downhill bonus is a local D8 slope trace, not a flow accumulation, debris-flow, or hydraulic model.
- This code is not validated for operational rescue, evacuation, medical, or infrastructure decisions. Confirm all critical outputs with local authorities and field teams.

## Hackathon materials

- [Submission report](SUBMISSION_REPORT.md) - methods, evaluation protocol, and limitations; no fabricated case-study scores.
- [Three-minute demo script](DEMO_SCRIPT.md) - suggested live walkthrough.
- [Case-study comparison runbook](CASE_STUDY_RUNBOOK.md) - how to run the Trishuli area and compare the official reference after analysis.

## Required attribution

Include these lines in a submitted report or exported map:

> Contains modified Copernicus Sentinel data 2026.

> Produced using Copernicus WorldDEM-30 © DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.

> © OpenStreetMap contributors.

Sentinel-1 RTC is accessed through Microsoft Planetary Computer. No training dataset is used. Include credit “European Union, Copernicus Emergency Management Service data” beside an EMSR927 reference map used for the validation comparison.

## Project layout

```text
track-b-flood-response/
├── app.py                  # Flask routes, Q&A, and one-page PDF export
├── flood_pipeline.py       # STAC scenes, raster change, historical OSM, graph analysis
├── templates/index.html    # Map desk interface
├── static/css/style.css    # Layout and map styling
├── static/js/app.js        # Map layers, report UI, and post-run comparison
├── requirements.txt
├── SUBMISSION_REPORT.md
├── DEMO_SCRIPT.md
└── CASE_STUDY_RUNBOOK.md
```

## License and third-party data

The application code in this package is offered under the MIT License. Satellite, elevation, and OSM data retain their respective providers' terms and required attribution. See `LICENSE`.
