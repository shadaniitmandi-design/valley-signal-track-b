# Trishuli case-study runbook

This runbook separates analysis inputs from reference data used only for checking.

## Before the run

1. Start Valley Signal and use event date `2026-08-26`.
2. Choose an AOI from the Trishuli corridor. Keep each side within 25 km. Record the four coordinates and area label.
3. Confirm that the analysis request contains only the AOI, event date, and optional upstream point. Do not load EMSR927 or post-event OSM layers yet.

## Save the system result

After the run, capture the displayed Sentinel-1 IDs, dates, relative orbit, and gap; the OSM snapshot timestamp; optional Sentinel-2 dates; DEM status; candidate flood area; asset intersections; isolated settlement names; and all coverage notes. Download the one-page situation report. Save a screenshot of the map with the layers named in the legend.

## Reference comparison (after analysis only)

1. Download an EMSR927 flood extent polygon from the [Copernicus EMS activation](https://mapping.emergency.copernicus.eu/activations/EMSR927/).
2. In Valley Signal, use **Choose reference GeoJSON** after the analysis result is visible.
3. Record the reported polygon IoU and visually inspect where the reference and candidate boundaries differ.
4. Keep the reference as a separate validation layer. Do not use it to tune thresholds and then report the same AOI as independent validation.
5. Credit: **European Union, Copernicus Emergency Management Service data**.

## Results table to complete from a live run

| Field | Value from the run |
|---|---|
| AOI name and bounds |  |
| Event date | 26 August 2026 |
| Sentinel-1 before / after IDs and dates |  |
| Relative orbit / pass / days between scenes |  |
| OSM snapshot timestamp |  |
| Flood candidate area (ha) |  |
| Buildings / roads / bridges intersecting |  |
| Newly disconnected mapped settlements |  |
| Sentinel-2 pair / optical check status |  |
| Copernicus DEM status |  |
| EMSR927 polygon IoU |  |
| Coverage notes and field checks needed |  |

An empty cell is intentionally not filled with an assumed or illustrative value.
