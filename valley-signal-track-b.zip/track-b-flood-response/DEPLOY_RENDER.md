# Deploy Valley Signal

This project runs a Flask server and satellite-processing API. Netlify Drop publishes static files, so it cannot run this app's Python routes. Deploy it as a Python web service instead.

## Render deployment

1. Put the contents of this project folder at the root of a GitHub repository. The root should contain `render.yaml`, `app.py`, and `requirements.txt`.
2. In Render, choose **New → Blueprint**, connect that repository, and deploy the blueprint. `render.yaml` pins Python 3.11, installs the dependencies, starts Gunicorn on Render's assigned port, and checks `/api/health`.
3. Open the `.onrender.com` URL Render gives you. The first visit may take a little longer if the free service has been idle.
4. For the first demo run, use a small area. The app limits each AOI side to 25 km and the satellite/API calls can take several minutes.

No environment secret is required for the default public data sources. If your ohsome account requires a key, add `OHSOME_API_KEY` in the Render service's **Environment** settings, then redeploy.

## Why the Netlify URL returned 404

The homepage is `templates/index.html`, which Flask renders from the `/` route in `app.py`. It is not a static `index.html` in the publish directory. More importantly, the browser calls `/api/analyze`, `/api/answer`, and `/api/report/...`; those routes only exist while the Flask server is running. Uploading this Python project as dropped files therefore publishes no working app entry point.

For a static Netlify deployment, the backend would need to be separately hosted and the frontend configured to call that backend. This package is configured as one Flask web service on Render.
