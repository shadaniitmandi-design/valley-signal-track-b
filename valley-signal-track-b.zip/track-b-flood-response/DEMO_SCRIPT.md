# Three-minute demo script

**0:00-0:20 | The need**  
“After a flood, ground reports can be incomplete. Valley Signal starts with a location and date and assembles a map-based first look from satellite scenes and the OpenStreetMap snapshot that existed before the event.”

**0:20-0:45 | Area and evidence rules**  
Show the Trishuli corridor, 26 August 2026, and the bounds. Point out that the blank map uses no current road basemap. Draw or enter a small AOI. Explain that the OSM snapshot is capped at 27 July 2026 for this event, and EMSR927 is not loaded into the analysis.

**0:45-1:35 | Run the analysis**  
Click **Run area analysis**. While sources load, show the Sentinel-1, optional Sentinel-2, and historic OSM rows. When complete, point out the actual Sentinel-1 dates, orbit, and gap. State that candidate flood pixels come from a transparent backscatter-change screen and slope mask, not from a trained Himalayan segmentation model.

**1:35-2:10 | Read the map**  
Toggle flood candidates and OSM roads, buildings, bridges, and settlements. Explain that counts mean mapped geometries intersect the candidate flood area. Open the coverage notes. If the DEM is present, click an upstream point and run again to show the optional terrain descent line; clarify it is not a flood forecast.

**2:10-2:40 | Copilot and reference check**  
Ask “Which settlements are cut off?” and switch the situation report to Nepali. Show that the response uses analysis facts and that the report does not generate unverified numbers. Only now load the official EMSR927 polygon and read the overlap value as a reference comparison, not an input.

**2:40-3:00 | Limits and next action**  
Export the one-page report. Close with the key limitation: satellite revisit is measured in days; this cannot provide minutes-ahead warning, confirm structural damage, or replace field reports. The map is a prioritization aid for verification, not an operational dispatch tool.
