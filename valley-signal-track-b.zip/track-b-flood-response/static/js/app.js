(() => {
  const $ = (id) => document.getElementById(id);
  const form = $("analysisForm");
  const runButton = $("runButton");
  const formError = $("formError");
  let currentResult = null;
  let reportLanguage = "en";
  let upstreamPoint = null;
  let drawnBounds = null;
  const resultLayers = {};
  let boundaryLayer = null;
  let referenceLayer = null;
  let drawControl = null;

  const map = L.map("map", { zoomControl: false, attributionControl: true, preferCanvas: true });
  L.control.zoom({ position: "bottomleft" }).addTo(map);
  map.setView([27.99, 85.22], 10);
  map.attributionControl.setPrefix("");
  map.attributionControl.addAttribution("Analysis context: pre-event OSM snapshot + satellite-derived layers");

  // Deliberately blank cartographic grid: no current road tiles or post-event map is an input.
  const Grid = L.GridLayer.extend({
    createTile(coords) {
      const tile = document.createElement("canvas");
      tile.width = tile.height = 256;
      tile.className = "blank-grid-tile";
      const ctx = tile.getContext("2d");
      ctx.strokeStyle = "rgba(96, 128, 112, 0.11)";
      ctx.lineWidth = 1;
      for (let p = 0.5; p < 256; p += 64) {
        ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, 256); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(256, p); ctx.stroke();
      }
      ctx.fillStyle = "rgba(84, 124, 102, 0.2)";
      for (let x = 32; x < 256; x += 64) for (let y = 32; y < 256; y += 64) {
        ctx.beginPath(); ctx.arc(x, y, 1.2, 0, Math.PI * 2); ctx.fill();
      }
      return tile;
    },
  });
  new Grid({ tileSize: 256, noWrap: true }).addTo(map);

  const drawnItems = new L.FeatureGroup().addTo(map);
  drawControl = new L.Draw.Rectangle(map, {
    shapeOptions: { color: "#236756", weight: 1.5, fillColor: "#4d9175", fillOpacity: 0.11, dashArray: "4, 4" },
  });
  new L.Control.Draw({
    position: "topright",
    draw: { polyline: false, polygon: false, circle: false, marker: false, circlemarker: false,
      rectangle: { shapeOptions: { color: "#236756", weight: 1.5, fillColor: "#4d9175", fillOpacity: 0.11, dashArray: "4, 4" } } },
    edit: { featureGroup: drawnItems, edit: false, remove: true },
  }).addTo(map);

  map.on(L.Draw.Event.CREATED, (event) => {
    drawnItems.clearLayers();
    drawnItems.addLayer(event.layer);
    drawnBounds = event.layer.getBounds();
    writeBounds(drawnBounds);
    updateAreaReadout();
  });
  map.on(L.Draw.Event.DELETED, () => { drawnBounds = null; });
  map.on("click", (event) => {
    if (!currentResult || !currentResult.satellite.dem_available) return;
    upstreamPoint = [event.latlng.lng, event.latlng.lat];
    if (window.upstreamMarker) map.removeLayer(window.upstreamMarker);
    window.upstreamMarker = L.circleMarker(event.latlng, {
      radius: 6, color: "#705491", fillColor: "#f8f5ff", fillOpacity: 1, weight: 2,
    }).addTo(map).bindTooltip("Upstream start · run analysis again to trace");
    setMapStatus("UPSTREAM POINT SET · RUN AGAIN", "active");
  });

  $("drawHint").addEventListener("click", () => drawControl.enable());
  $("fitBounds").addEventListener("click", () => fitCurrentBounds());
  $("clearLayers").addEventListener("click", () => clearAnalysis());
  for (const id of ["west", "south", "east", "north"]) $(id).addEventListener("change", updateAreaReadout);

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    formError.hidden = true;
    const bbox = ["west", "south", "east", "north"].map((id) => Number($(id).value));
    if (bbox.some((n) => !Number.isFinite(n))) return showError("Enter four valid coordinates for the area bounds.");
    setLoading(true);
    setMapStatus("SEARCHING STAC · OHSOME", "active");
    $("mapEmpty").hidden = true;
    $("analysisStamp").className = "analysis-stamp loading";
    $("analysisStamp").querySelector("b").textContent = "SEARCHING SOURCES";
    $("analysisStamp").querySelector("small").textContent = "This can take a few minutes";
    try {
      const response = await fetch("/api/analyze", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          area_name: $("areaName").value,
          event_date: $("eventDate").value,
          bbox,
          ...(upstreamPoint ? { upstream: upstreamPoint } : {}),
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Analysis failed.");
      currentResult = result;
      upstreamPoint = null;
      renderResult(result);
    } catch (error) {
      showError(error.message || "Could not finish the analysis. Check the server log and data access.");
      setMapStatus("ANALYSIS DID NOT COMPLETE", "");
      $("analysisStamp").className = "analysis-stamp";
      $("analysisStamp").querySelector("b").textContent = "SOURCE CHECK NEEDED";
      $("analysisStamp").querySelector("small").textContent = "Review the message at left";
    } finally {
      setLoading(false);
    }
  });

  function showError(message) {
    formError.textContent = message;
    formError.hidden = false;
  }

  function setLoading(loading) {
    runButton.disabled = loading;
    runButton.querySelector(".run-button-label").textContent = loading ? "Searching scenes and OSM…" : "Run area analysis";
  }

  function setMapStatus(message, state) {
    const el = $("mapStatus");
    el.className = `map-status ${state || ""}`;
    el.querySelector("span").textContent = message;
  }

  function readBounds() {
    const values = ["west", "south", "east", "north"].map((id) => Number($(id).value));
    if (values.some((x) => !Number.isFinite(x)) || values[0] >= values[2] || values[1] >= values[3]) return null;
    return values;
  }

  function updateAreaReadout() {
    const bounds = readBounds();
    if (!bounds) { $("areaSize").textContent = "Enter valid coordinate bounds"; return; }
    const [west, south, east, north] = bounds;
    const width = (east - west) * 111.2 * Math.cos(((south + north) / 2) * Math.PI / 180);
    const height = (north - south) * 111.2;
    $("areaSize").textContent = `Approx. ${width.toFixed(1)} × ${height.toFixed(1)} km`;
  }

  function writeBounds(bounds) {
    $("west").value = bounds.getWest().toFixed(5);
    $("south").value = bounds.getSouth().toFixed(5);
    $("east").value = bounds.getEast().toFixed(5);
    $("north").value = bounds.getNorth().toFixed(5);
  }

  function fitCurrentBounds() {
    if (currentResult?.bbox) {
      const [w, s, e, n] = currentResult.bbox;
      map.fitBounds([[s, w], [n, e]], { padding: [28, 28] });
      return;
    }
    const bbox = readBounds();
    if (bbox) map.fitBounds([[bbox[1], bbox[0]], [bbox[3], bbox[2]]], { padding: [28, 28] });
  }

  function clearAnalysis() {
    for (const layer of Object.values(resultLayers)) map.removeLayer(layer);
    Object.keys(resultLayers).forEach((key) => delete resultLayers[key]);
    if (referenceLayer) map.removeLayer(referenceLayer);
    if (window.upstreamMarker) map.removeLayer(window.upstreamMarker);
    if (boundaryLayer) map.removeLayer(boundaryLayer);
    drawnItems.clearLayers();
    drawnBounds = null;
    currentResult = null;
    upstreamPoint = null;
    referenceLayer = null;
    $("mapEmpty").hidden = false;
    $("mapAreaLabel").textContent = "/ NO AOI LOADED";
    $("mapCoords").textContent = "Draw a rectangle or enter bounds";
    $("analysisStamp").className = "analysis-stamp";
    $("analysisStamp").querySelector("b").textContent = "READY FOR ANALYSIS";
    $("analysisStamp").querySelector("small").textContent = "Choose an area to begin";
    setMapStatus("Awaiting analysis", "");
    ["metricFlood", "metricBuildings", "metricRoads", "metricBridges", "metricSettlements"].forEach((id) => $(id).textContent = "—");
    $("s1Before").textContent = "—"; $("s1After").textContent = "—"; $("sceneGap").textContent = "—";
    $("orbitTag").textContent = "S1 · WAITING"; $("s2Status").textContent = "Sentinel-2 optical check: not run";
    $("demStatus").textContent = "DEM: not run"; $("sitrepText").textContent = "Run an area analysis to generate a short, evidence-grounded report in English or Nepali.";
    $("downloadReport").disabled = true; $("answerBox").innerHTML = "<span>Answers are generated from this analysis record; no numbers are inferred by a language model.</span>";
    $("referenceResult").hidden = true; $("referenceName").textContent = "No reference loaded";
  }

  function renderResult(result) {
    if (boundaryLayer) map.removeLayer(boundaryLayer);
    const [west, south, east, north] = result.bbox;
    boundaryLayer = L.rectangle([[south, west], [north, east]], {
      color: "#648879", weight: 1, dashArray: "5 4", fill: false, interactive: false,
    }).addTo(map);
    for (const layer of Object.values(resultLayers)) map.removeLayer(layer);
    Object.keys(resultLayers).forEach((key) => delete resultLayers[key]);

    const layerDefs = {
      flood_candidates: { style: () => ({ className: "flood-shape", color: "#c94f3b", weight: 1.4, fillColor: "#dd654d", fillOpacity: 0.42 }) },
      optical_confirmation: { style: () => ({ className: "optical-shape", color: "#397c95", weight: 1.2, fillColor: "#4c94af", fillOpacity: 0.26 }) },
      roads: { style: (f) => f.properties?.intersects_flood_candidate
        ? { className: "road-hit-shape", color: "#d68a3d", weight: 2.8, opacity: .95 }
        : { className: "road-shape", color: "#557c71", weight: 1.3, opacity: .82 } },
      buildings: { style: (f) => f.properties?.intersects_flood_candidate
        ? { className: "building-hit-shape", color: "#a96f24", weight: .8, fillColor: "#e3aa50", fillOpacity: .85 }
        : { className: "building-shape", color: "#426d5e", weight: .5, fillColor: "#799c8a", fillOpacity: .64 } },
      bridges: { style: () => ({ className: "bridge-shape", color: "#b56742", weight: 3.5, opacity: .95 }) },
      isolated_settlements: { pointToLayer: (f, latlng) => {
        const marker = L.marker(latlng, {
          icon: L.divIcon({ className: "", html: '<span class="isolation-marker"></span>', iconSize: [13, 13], iconAnchor: [6, 6] }),
        });
        marker.bindTooltip(escapeHtml(f.properties?.name || "Mapped settlement"));
        return marker;
      } },
      downstream_path: { style: () => ({ className: "path-shape", color: "#705491", weight: 3, dashArray: "5, 5" }) },
    };
    for (const [name, definition] of Object.entries(layerDefs)) {
      const geojson = result.layers?.[name];
      if (!geojson?.features?.length) continue;
      resultLayers[name] = L.geoJSON(geojson, definition);
      if (document.querySelector(`.layer-toggle[data-layer="${name}"]`)?.classList.contains("active")) resultLayers[name].addTo(map);
    }
    $("mapEmpty").hidden = true;
    $("mapAreaLabel").textContent = `/ ${result.area_name.toUpperCase()}`;
    $("mapCoords").textContent = `${west.toFixed(3)}°E, ${south.toFixed(3)}°N  →  ${east.toFixed(3)}°E, ${north.toFixed(3)}°N`;
    setMapStatus(`ANALYSIS READY · OSM ${result.osm_snapshot.slice(0, 10)}`, "done");
    map.fitBounds([[south, west], [north, east]], { padding: [28, 28] });

    const s = result.summary;
    $("metricFlood").innerHTML = `${s.flood_ha.toFixed(1)}<small>ha</small>`;
    $("metricBuildings").textContent = s.buildings_hit;
    $("metricRoads").textContent = s.roads_hit;
    $("metricBridges").textContent = s.bridges_hit;
    $("metricSettlements").textContent = s.settlements_cut_off;
    $("s1Before").textContent = result.satellite.s1_before.date;
    $("s1After").textContent = result.satellite.s1_after.date;
    $("sceneGap").textContent = `${result.satellite.gap_days} days`;
    $("orbitTag").textContent = `S1 · ${result.satellite.orbit_direction.toUpperCase()} · ORBIT ${result.satellite.relative_orbit}`;
    $("s2Status").textContent = result.satellite.s2_scenes
      ? `Sentinel-2 check: ${result.satellite.s2_scenes.before} / ${result.satellite.s2_scenes.after}${s.optical_confirmation_ha == null ? "" : ` · ${s.optical_confirmation_ha} ha water gain`}`
      : "Sentinel-2 optical check: unavailable for this date";
    $("demStatus").textContent = result.satellite.dem_available ? "Copernicus DEM: available" : "Copernicus DEM: unavailable";
    $("analysisStamp").className = "analysis-stamp complete";
    $("analysisStamp").querySelector("b").textContent = "ANALYSIS COMPLETE";
    $("analysisStamp").querySelector("small").textContent = `${result.warnings?.length || 0} coverage notes`;
    $("downloadReport").disabled = false;
    $("sitrepText").textContent = result.sitrep[reportLanguage];
    $("answerBox").innerHTML = "<span>Try a question above. Answers use this analysis record only.</span>";
    if (result.warnings?.length) showError(result.warnings.join(" "));
    else formError.hidden = true;
    if (result.downstream) {
      $("answerBox").textContent = `Downstream trace: ${result.downstream.distance_km} km. Nearby mapped settlements: ${result.downstream.settlements_along_path.join(", ") || "none identified"}. This is a terrain-only line, not a flood forecast.`;
    }
  }

  document.querySelectorAll(".layer-toggle").forEach((button) => button.addEventListener("click", () => {
    button.classList.toggle("active");
    const layer = resultLayers[button.dataset.layer];
    if (!layer) return;
    if (button.classList.contains("active")) layer.addTo(map); else map.removeLayer(layer);
  }));

  document.querySelectorAll(".lang-button").forEach((button) => button.addEventListener("click", () => {
    reportLanguage = button.dataset.lang;
    document.querySelectorAll(".lang-button").forEach((x) => x.classList.toggle("active", x === button));
    if (currentResult) $("sitrepText").textContent = currentResult.sitrep[reportLanguage];
  }));

  $("downloadReport").addEventListener("click", () => {
    if (currentResult?.id) window.location.assign(`/api/report/${currentResult.id}.pdf`);
  });

  document.querySelectorAll(".suggestion").forEach((button) => button.addEventListener("click", () => {
    $("questionInput").value = button.dataset.question;
    $("questionForm").requestSubmit();
  }));
  $("questionForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!currentResult) {
      $("answerBox").textContent = "Run an analysis first. The assistant has no evidence record to answer from.";
      return;
    }
    const question = $("questionInput").value.trim();
    if (!question) return;
    $("answerBox").textContent = "Checking the mapped evidence…";
    try {
      const response = await fetch("/api/answer", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result_id: currentResult.id, question, language: reportLanguage }),
      });
      const answer = await response.json();
      $("answerBox").textContent = answer.answer || answer.error || "No mapped answer found.";
    } catch {
      $("answerBox").textContent = "Could not reach the report assistant.";
    }
  });

  $("referenceFile").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    $("referenceName").textContent = file.name;
    $("referenceResult").hidden = true;
    if (!currentResult) {
      $("referenceResult").textContent = "Run the satellite analysis first; reference maps are for checking only.";
      $("referenceResult").hidden = false;
      return;
    }
    try {
      const reference = JSON.parse(await file.text());
      const referenceFeatures = reference.type === "FeatureCollection" ? reference.features : [reference];
      const flood = currentResult.layers.flood_candidates.features;
      if (!flood.length) throw new Error("No flood candidate polygon is available to compare.");
      const candidateUnion = turf.combine(turf.featureCollection(flood)).features[0];
      const refPolygons = referenceFeatures.filter((f) => ["Polygon", "MultiPolygon"].includes(f?.geometry?.type));
      if (!refPolygons.length) throw new Error("The reference file needs polygon features.");
      const referenceUnion = turf.combine(turf.featureCollection(refPolygons)).features[0];
      if (!candidateUnion || !referenceUnion) throw new Error("Could not read the polygon geometries.");
      const intersection = turf.intersect(candidateUnion, referenceUnion);
      const combined = turf.union(candidateUnion, referenceUnion);
      const overlap = intersection ? (turf.area(intersection) / turf.area(combined)) * 100 : 0;
      if (referenceLayer) map.removeLayer(referenceLayer);
      referenceLayer = L.geoJSON(reference, { style: () => ({ className: "reference-shape", color: "#755d9c", weight: 1.5, dashArray: "4,3", fillColor: "#8f74b8", fillOpacity: .12 }) }).addTo(map);
      $("referenceResult").textContent = `Reference-only check · polygon IoU ${overlap.toFixed(1)}% · does not change analysis`;
      $("referenceResult").hidden = false;
    } catch (error) {
      $("referenceResult").textContent = `Could not compare: ${error.message}`;
      $("referenceResult").hidden = false;
    }
  });

  $("aboutButton").addEventListener("click", () => $("aboutDialog").showModal());
  $("closeAbout").addEventListener("click", () => $("aboutDialog").close());
  $("aboutDialog").addEventListener("click", (event) => { if (event.target === $("aboutDialog")) $("aboutDialog").close(); });

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]);
  }

  updateAreaReadout();
})();
