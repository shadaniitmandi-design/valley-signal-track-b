# Valley Signal: Mapping Flood Damage from Space

**Multimodal AI Hackathon 2026 - Track B**  
Prototype report · 15 October 2026

## 1. Operational question

When roads and communications fail, response teams need a fast first look at flood extent, exposed infrastructure, and settlements that may have lost road access. Valley Signal turns open satellite imagery and a dated OpenStreetMap snapshot into a small, inspectable map brief. It is designed to narrow field checks, not to replace them.

The case-study entry point is 26 August 2026, around the Bhote Koshi-Trishuli corridor in northern Nepal. The supplied workspace runs a bounded area of interest (AOI) at a time. The initial Trishuli AOI can be resized or redrawn; the system searches sources from scratch for the submitted area and date.

## 2. Data and safeguards

Sentinel-1 RTC VV scenes are read from the public Microsoft Planetary Computer STAC catalog. Pair selection requires the same relative orbit and pass direction. Among matching scenes within 36 days before and after the event, the score favors a repeat interval near 12 days while keeping acquisitions close to the event. The chosen IDs and dates are retained with the analysis.

Sentinel-2 L2A is optional. A before/after pair with scene cloud cover no greater than 35% is used for a separate NDWI change layer when available. The scene classification layer removes cloud, cloud shadow, snow, and invalid pixels. Optical data does not override radar candidates.

Copernicus WorldDEM-30 is used for a coarse slope screen and optional downhill trace. OSM roads, buildings, bridges, settlements, and hospitals are requested from the ohsome history API at a time before the flood. For the August 2026 event, the code uses the 27 July 2026 snapshot stated in the challenge. A 5 km context margin gives the road graph nearby network links and anchors; displayed asset intersections and settlement candidates remain inside the chosen AOI.

The comparison with EMSR927 is separated from analysis. A user uploads a reference polygon after the satellite run; the browser reports spatial intersection-over-union but sends nothing back to the analysis server. No published damage map, post-event OSM edit, or training dataset is used as an input.

## 3. Method

### Flood candidates

The two Sentinel-1 VV scenes are warped to a shared projected 20 m grid. Linear-power values are converted to decibels when needed. A pixel is marked as a candidate when post-event VV is below -15 dB and is at least 2.5 dB darker than the pre-event value. If the DEM is available, candidates on slopes over 20 degrees are excluded. Connected components smaller than six pixels are removed, then the result is polygonized and simplified for display.

This is a transparent change-detection baseline. It is not a trained segmentation model and has no learned Himalayan performance score. Thresholds may need tuning for terrain, incidence angle, vegetation, and event duration.

### Exposure and access

Mapped roads, bridges, and buildings are counted as exposed when their geometry intersects a 10 m buffer around candidate polygons. The count describes map geometry intersections, not structural failure.

The road screen makes a graph from mapped road centerlines, excluding pedestrian-only paths. It compares connected components before and after removing road segments that intersect the candidate flood buffer. A mapped settlement is counted only if it was connected to a mapped town or hospital before removal and loses all such connections afterward. The analysis reports a coverage note because missing OSM roads, the AOI edge, and mapped facility gaps can change the result.

When requested, the bonus path starts at a user-selected point and repeatedly moves to the lowest neighboring DEM cell. Nearby OSM settlements are listed along the resulting line. This is a terrain-only descent and does not model channel flow, water depth, debris, or travel time.

## 4. AI component and interface

The chosen AI component is a bilingual, evidence-bounded situation-report copilot. It creates a concise English or Nepali summary and answers common questions about buildings, roads, bridges, scene dates, and disconnected settlements. The current prototype uses intent rules and fact slots populated from the analysis record rather than a generative language model. This is deliberate: every number in the report is a value already computed by the raster or vector analysis, and each answer can be traced to a stored layer or metric.

The map uses a local coordinate grid rather than current basemap tiles. This keeps the visualization consistent with the challenge's pre-event OSM input rule. Layer toggles distinguish Sentinel-1 flood candidates, optional optical change, OSM features, exposed assets, isolated settlements, and the optional downhill trace. A one-page PDF report can be exported from each completed analysis.

## 5. Case-study evaluation protocol

The submission must be run against the Trishuli AOI with event date 26 August 2026 and the resulting satellite acquisition pair recorded. Upload the official EMSR927 flood polygon only after the run. The interface computes intersection-over-union between the generated candidate extent and the reference geometry. Compare and discuss the results by AOI; do not merge the reference polygons into the predicted layer.

The package intentionally makes no numeric flood-area, exposed-asset, or EMSR927-overlap claim before it has queried the satellite and OSM sources for the selected AOI. Live scene availability, valid cloud-free optical pairs, and OSM extraction can differ by AOI. The values shown after a run are the reportable result. The included [runbook](CASE_STUDY_RUNBOOK.md) records the sequence and evidence to save for the final presentation.

For a stronger evaluation, freeze the AOI and event date, save the selected scene IDs, repeat the run with the same settings, and report: candidate area; OSM snapshot timestamp; exposed buildings, roads, and bridges; newly disconnected settlements; EMSR927 IoU; and map coverage notes. A visual boundary comparison should accompany IoU because the official map and pixel grid may use different delineation scales.

## 6. Limitations and responsibility

Sentinel satellites revisit on a scale of days; these observations cannot warn minutes before a sudden glacier collapse. The first post-event image may arrive after water recedes. Radar shadows, topography, vegetation, soil moisture, mixed pixels, and scene alignment can create omission or commission errors. Optical imagery can be obscured by monsoon cloud. The 20 m surface misses narrow channels and small structures.

OpenStreetMap coverage and tags vary. An intersection is not proof of damage. A missing road can create false isolation; an untagged footpath or a temporary repair can make the graph result wrong. No population, mobile-phone, field-report, road-condition, bridge-capacity, flood-depth, or hospital-capacity data is modeled. The terrain path is not a hydraulic or debris-flow forecast.

This prototype has not been calibrated against field labels, independently validated on unseen Himalayan scenes, or approved for operational use. Before a response decision, local authorities and field teams must confirm satellite interpretations, road status, settlement access, and infrastructure damage. Do not use the system alone to dispatch rescue teams, evacuate, or allocate supplies.

## Attribution

Contains modified Copernicus Sentinel data 2026.

Produced using Copernicus WorldDEM-30 © DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.

© OpenStreetMap contributors.

Sentinel scenes are accessed through Microsoft Planetary Computer. No training dataset was used. EMSR927 reference material is credited “European Union, Copernicus Emergency Management Service data” when included in the validation map.
