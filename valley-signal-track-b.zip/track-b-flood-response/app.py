from __future__ import annotations

import io
import os
import uuid
from datetime import date

from flask import Flask, jsonify, render_template, request, send_file
from dotenv import load_dotenv

load_dotenv()
from flood_pipeline import AnalysisError, analyze_area, build_sitrep

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False
RESULTS: dict[str, dict] = {}


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({"status": "ready", "as_of": date.today().isoformat(), "mode": "live"})


@app.post("/api/analyze")
def analyze():
    body = request.get_json(silent=True) or {}
    try:
        result = analyze_area(body)
        result_id = str(uuid.uuid4())
        result["id"] = result_id
        result["sitrep"] = {
            "en": build_sitrep(result, "en"),
            "ne": build_sitrep(result, "ne"),
        }
        RESULTS[result_id] = result
        return jsonify(result)
    except AnalysisError as exc:
        return jsonify({"error": str(exc), "kind": "analysis"}), 422
    except Exception as exc:  # return a useful field error rather than a blank UI
        app.logger.exception("Analysis failed")
        return jsonify({"error": f"Analysis could not finish: {exc}", "kind": "provider"}), 502


@app.post("/api/answer")
def answer():
    body = request.get_json(silent=True) or {}
    result = RESULTS.get(str(body.get("result_id", "")))
    if result is None:
        return jsonify({"error": "Run an analysis before asking the report assistant."}), 404
    language = "ne" if body.get("language") == "ne" else "en"
    question = str(body.get("question", "")).strip().lower()
    if not question:
        return jsonify({"error": "Enter a question about the mapped results."}), 400
    return jsonify({"answer": answer_from_evidence(result, question, language)})


@app.get("/api/report/<result_id>.pdf")
def report_pdf(result_id: str):
    result = RESULTS.get(result_id)
    if result is None:
        return jsonify({"error": "This analysis is no longer in memory. Run it again to export the report."}), 404
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=0.62 * inch,
                            leftMargin=0.62 * inch, topMargin=0.55 * inch,
                            bottomMargin=0.55 * inch, title="Valley Signal - Situation Report")
    base = getSampleStyleSheet()
    title = ParagraphStyle("TitleCustom", parent=base["Title"], fontName="Helvetica-Bold",
                           fontSize=20, leading=23, alignment=TA_LEFT, textColor=colors.HexColor("#142b34"),
                           spaceAfter=4)
    small = ParagraphStyle("SmallCustom", parent=base["BodyText"], fontSize=8.4, leading=11,
                           textColor=colors.HexColor("#54676c"))
    body = ParagraphStyle("BodyCustom", parent=base["BodyText"], fontSize=9.4, leading=13,
                          textColor=colors.HexColor("#243c43"), spaceAfter=5)
    story = [Paragraph("VALLEY SIGNAL", small), Paragraph("Preliminary flood situation report", title)]
    story.append(Paragraph(
        f"<b>{safe_pdf(result['area_name'])}</b> &nbsp; / &nbsp; Event date: {safe_pdf(result['event_date'])} "
        f"&nbsp; / &nbsp; OSM snapshot: {safe_pdf(result['osm_snapshot'])}", body))
    summary = result["summary"]
    rows = [
        ["Mapped flood candidates", f"{summary['flood_ha']:.1f} ha"],
        ["OSM buildings intersecting candidate extent", str(summary["buildings_hit"])],
        ["Road features intersecting candidate extent", str(summary["roads_hit"])],
        ["Mapped bridges intersecting candidate extent", str(summary["bridges_hit"])],
        ["Settlements newly disconnected in road graph", str(summary["settlements_cut_off"])],
    ]
    table = Table(rows, colWidths=[4.65 * inch, 1.7 * inch], rowHeights=0.32 * inch)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f0f4f2")),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#1f373e")),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica"), ("FONTNAME", (1, 0), (1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 9), ("GRID", (0, 0), (-1, -1), 0.5, colors.white),
    ]))
    story += [Spacer(1, 5), table, Spacer(1, 9), Paragraph("Assessment", base["Heading2"]),
              Paragraph(safe_pdf(result["sitrep"]["en"]), body)]
    scenes = result["satellite"]
    story += [Paragraph("Evidence and method", base["Heading2"]), Paragraph(
        f"Sentinel-1 RTC scenes: {safe_pdf(scenes['s1_before']['date'])} and "
        f"{safe_pdf(scenes['s1_after']['date'])}; relative orbit {safe_pdf(str(scenes['relative_orbit']))}, "
        f"{safe_pdf(scenes['orbit_direction'])} pass. Flood candidates use a VV backscatter decrease "
        "and low post-event backscatter, with a terrain-slope screen when the DEM is available. "
        "Asset intersections and road connectivity use the dated OpenStreetMap snapshot shown above.", body)]
    warnings = result.get("warnings", [])
    if warnings:
        story += [Paragraph("Coverage notes", base["Heading2"]), Paragraph("<br/>".join(safe_pdf(w) for w in warnings), body)]
    story += [Paragraph("Use and limitations", base["Heading2"]), Paragraph(
        "This is an educational, preliminary remote-sensing assessment. A detected intersection is not "
        "field-confirmed structural damage. Radar change can be affected by terrain shadow, vegetation, "
        "soil moisture, and acquisition geometry. OSM completeness varies. Satellite revisit intervals "
        "cannot provide minute-scale warning. Do not use this output alone to direct rescue or evacuation.", body),
        Spacer(1, 5), Paragraph(
            'Contains modified Copernicus Sentinel data 2026. Produced using Copernicus WorldDEM-30 '
            '© DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS '
            'by the European Union and ESA; all rights reserved. © OpenStreetMap contributors. '
            'Sentinel-1 RTC accessed through Microsoft Planetary Computer. No EMSR927 reference data '
            'was used as an analysis input.', small)]
    doc.build(story)
    buffer.seek(0)
    return send_file(buffer, mimetype="application/pdf", as_attachment=True,
                     download_name="valley-signal-situation-report.pdf")


def safe_pdf(value: str) -> str:
    from xml.sax.saxutils import escape
    return escape(str(value))


def answer_from_evidence(result: dict, question: str, language: str) -> str:
    s = result["summary"]
    if language == "ne":
        if any(word in question for word in ("settlement", "village", "cut", "टोल", "बस्ती", "सम्पर्क")):
            names = ", ".join(x.get("properties", {}).get("name", "नाम नखुलेको बस्ती")
                               for x in result["layers"]["isolated_settlements"]["features"][:6])
            if not names:
                return f"यस सडक-नेटवर्क विश्लेषणमा {s['settlements_cut_off']} बस्ती नयाँ रूपमा सम्पर्कविहीन देखिएनन्। यो OSM र नक्साङ्कन गरिएको बाढी क्षेत्रको प्रारम्भिक अनुमान हो।"
            return f"सडक-जडान विश्लेषणमा {s['settlements_cut_off']} बस्ती नयाँ रूपमा विच्छेद भएको देखियो: {names}। स्थलमै पुष्टि आवश्यक छ।"
        if any(word in question for word in ("building", "घर", "भवन")):
            return f"नक्साङ्कन गरिएको बाढी सम्भावित क्षेत्रमा {s['buildings_hit']} OSM भवन खण्ड परे। यसले संरचनात्मक क्षति पुष्टि गर्दैन।"
        if any(word in question for word in ("road", "bridge", "सडक", "पुल")):
            return f"बाढी सम्भावित क्षेत्रसँग {s['roads_hit']} सडक र {s['bridges_hit']} नक्साङ्कित पुल खण्ड मिले। कृपया फिल्डबाट पुष्टि गर्नुहोस्।"
        return f"{result['area_name']} मा प्रारम्भिक बाढी सम्भावित क्षेत्र {s['flood_ha']:.1f} हेक्टर छ। यो उपग्रह परिवर्तनको अनुमान हो, पुष्टि गरिएको क्षति होइन।"
    if any(word in question for word in ("settlement", "village", "cut off", "isolat", "town")):
        features = result["layers"]["isolated_settlements"]["features"][:6]
        names = ", ".join(x["properties"].get("name", "unnamed settlement") for x in features)
        if not names:
            return f"The road graph found no newly disconnected mapped settlements in this AOI. OSM gaps and the analysis boundary can hide real access loss."
        return f"The road graph flags {s['settlements_cut_off']} newly disconnected mapped settlements: {names}. Treat these as priority checks, not confirmed access loss."
    if any(word in question for word in ("building", "house", "home", "damaged", "damage")):
        return f"{s['buildings_hit']} mapped OSM buildings intersect the satellite-derived flood candidate area. The system estimates exposure; it does not confirm structural damage."
    if any(word in question for word in ("road", "bridge", "route")):
        return f"The flood candidate area intersects {s['roads_hit']} mapped road features and {s['bridges_hit']} mapped bridges in the {result['osm_snapshot']} OSM snapshot. Intersections need field verification."
    if any(word in question for word in ("when", "image", "date", "sensor", "sentinel")):
        sat = result["satellite"]
        return f"Sentinel-1 RTC scenes were acquired on {sat['s1_before']['date']} and {sat['s1_after']['date']} on relative orbit {sat['relative_orbit']} ({sat['orbit_direction']}). The OSM reference is dated {result['osm_snapshot']}."
    return f"For {result['area_name']} on {result['event_date']}, the mapped flood candidate is {s['flood_ha']:.1f} ha, with {s['buildings_hit']} buildings, {s['roads_hit']} roads, {s['bridges_hit']} bridges intersected and {s['settlements_cut_off']} newly disconnected settlements. These are map-derived estimates, not field-confirmed impacts."


if __name__ == "__main__":
    app.run(host=os.getenv("FLASK_HOST", "127.0.0.1"), port=int(os.getenv("FLASK_PORT", "5055")), debug=False)
