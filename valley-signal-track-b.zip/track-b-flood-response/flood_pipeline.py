from __future__ import annotations

import math
import os
from datetime import date, datetime, time, timedelta, timezone
from itertools import pairwise
from typing import Any

import networkx as nx
import numpy as np
import planetary_computer as pc
import rasterio
import requests
from scipy import ndimage
from pystac_client import Client
from pyproj import Transformer
from rasterio.enums import Resampling
from rasterio.features import geometry_mask, shapes
from rasterio.transform import from_origin
from rasterio.vrt import WarpedVRT
from rasterio.warp import transform_bounds
from shapely.geometry import LineString, Polygon, shape, mapping
from shapely.ops import transform as transform_geometry, unary_union


PC_STAC = "https://planetarycomputer.microsoft.com/api/stac/v1"
OH_API = os.getenv("OHSOME_API_URL", "https://api.ohsome.org/v1").rstrip("/")
OSM_MAX_SNAPSHOT = datetime(2026, 7, 27, 23, 59, 59, tzinfo=timezone.utc)
RESOLUTION_M = 20
MAX_PIXELS = 1_800_000


class AnalysisError(ValueError):
    pass


def analyze_area(body: dict[str, Any]) -> dict[str, Any]:
    area_name = str(body.get("area_name", "Trishuli corridor")).strip()[:100] or "Unnamed area"
    event_date = parse_event_date(str(body.get("event_date", "")))
    bbox = parse_bbox(body.get("bbox"))
    snapshot = choose_osm_snapshot(event_date)

    catalog = Client.open(PC_STAC, modifier=pc.sign_inplace)
    s1_before, s1_after, orbit, direction = find_sentinel1_pair(catalog, bbox, event_date)
    s2_pair = find_sentinel2_pair(catalog, bbox, event_date)

    # Raster analysis uses a common projected grid clipped to the requested AOI.
    before_href = signed_asset(s1_before, "vv")
    after_href = signed_asset(s1_after, "vv")
    with rasterio.open(before_href) as before_ds:
        if before_ds.crs is None:
            raise AnalysisError("The selected Sentinel-1 scene has no projected CRS.")
        dst_crs = before_ds.crs
        grid = make_grid(bbox, dst_crs)
        before = read_on_grid(before_ds, grid)
        before = to_db(before, before_ds)
    with rasterio.open(after_href) as after_ds:
        after = read_on_grid(after_ds, grid)
        after = to_db(after, after_ds)

    dem = read_dem(catalog, bbox, grid)
    valid = np.isfinite(before) & np.isfinite(after) & grid["aoi_mask"]
    change = after - before
    flood_mask = valid & (after < -15.0) & (change < -2.5)
    if dem is not None:
        slope = slope_degrees(dem, grid["resolution"])
        flood_mask &= np.isfinite(slope) & (slope <= 20.0)
    flood_mask = remove_small_components(flood_mask, min_pixels=6)
    flood_m = polygonize_mask(flood_mask, grid)
    # The classification deliberately remains SAR-led. Clear optical scenes provide a separate
    # corroboration layer, rather than silently suppressing radar detections when clouds remain.
    optical_m = None
    optical_dates = None
    if s2_pair:
        try:
            optical_m = optical_water_gain(s2_pair, grid)
            optical_dates = {"before": item_date(s2_pair[0]), "after": item_date(s2_pair[1])}
        except Exception as exc:
            optical_m = None
            optical_dates = None
            optical_note = f"Sentinel-2 was found but could not be read: {exc}"
        else:
            optical_note = ""
    else:
        optical_note = "No suitable clear Sentinel-2 before/after pair was found; the flood layer uses Sentinel-1 only."
    s2_m = polygonize_mask(optical_m, grid) if optical_m is not None else None

    warnings: list[str] = []
    if dem is None:
        warnings.append("Copernicus DEM was unavailable for this AOI; no terrain-slope screen or downstream trace was applied.")
    if optical_note:
        warnings.append(optical_note)
    if orbit is None:
        warnings.append("Sentinel-1 relative-orbit metadata was missing; same-track pairing could not be independently confirmed.")
    if flood_m is None or flood_m.is_empty:
        warnings.append("No pixels met the initial flood-change thresholds. This does not prove that flooding did not occur.")

    osm = load_osm_snapshot(bbox, snapshot)
    metrics, layers, osm_warnings = assess_assets(osm, flood_m, bbox, grid["crs"])
    warnings.extend(osm_warnings)
    cut_off = assess_connectivity(osm["roads"], osm["settlements"], osm["anchors"], flood_m, bbox, grid["crs"])
    layers["isolated_settlements"] = feature_collection(cut_off["features"])
    metrics["settlements_cut_off"] = len(cut_off["features"])
    if cut_off["warning"]:
        warnings.append(cut_off["warning"])

    trace = None
    if body.get("upstream") and dem is not None:
        try:
            trace = trace_downstream(body["upstream"], dem, grid, osm["settlements"])
            layers["downstream_path"] = feature_collection([trace["feature"]]) if trace["feature"] else feature_collection([])
        except (AnalysisError, ValueError, IndexError) as exc:
            warnings.append(f"Downstream trace was not produced: {exc}")
            layers["downstream_path"] = feature_collection([])
    else:
        layers["downstream_path"] = feature_collection([])

    flood_geo = reproject_geom(flood_m, grid["crs"], "EPSG:4326") if flood_m is not None and not flood_m.is_empty else None
    s2_geo = reproject_geom(s2_m, grid["crs"], "EPSG:4326") if s2_m is not None and not s2_m.is_empty else None
    layers["flood_candidates"] = feature_collection(
        [{"type": "Feature", "geometry": mapping(flood_geo),
          "properties": {"layer": "flood_candidate", "method": "Sentinel-1 RTC VV change", "estimated_ha": round(flood_m.area / 10_000, 1)}}]
        if flood_geo else [])
    layers["optical_confirmation"] = feature_collection(
        [{"type": "Feature", "geometry": mapping(s2_geo),
          "properties": {"layer": "optical_water_gain", "method": "Sentinel-2 NDWI change"}}]
        if s2_geo else [])

    s1_gap = abs((parse_item_datetime(s1_after) - parse_item_datetime(s1_before)).days)
    s2_confirmation_area = (s2_m.area / 10_000) if s2_m is not None and not s2_m.is_empty else None
    return {
        "area_name": area_name,
        "event_date": event_date.isoformat(),
        "bbox": bbox,
        "osm_snapshot": snapshot.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "summary": {
            "flood_ha": (flood_m.area / 10_000) if flood_m is not None and not flood_m.is_empty else 0.0,
            "buildings_hit": metrics["buildings_hit"],
            "roads_hit": metrics["roads_hit"],
            "bridges_hit": metrics["bridges_hit"],
            "settlements_cut_off": metrics["settlements_cut_off"],
            "optical_confirmation_ha": round(s2_confirmation_area, 1) if s2_confirmation_area is not None else None,
        },
        "satellite": {
            "s1_before": scene_summary(s1_before),
            "s1_after": scene_summary(s1_after),
            "relative_orbit": orbit if orbit is not None else "unavailable",
            "orbit_direction": direction or "unavailable",
            "gap_days": s1_gap,
            "s2_scenes": optical_dates,
            "dem_available": dem is not None,
            "method": f"Sentinel-1 RTC VV backscatter decrease with a low post-event threshold; {grid['resolution']:.0f} m analysis grid.",
        },
        "layers": layers,
        "downstream": {k: v for k, v in (trace or {}).items() if k != "feature"} if trace else None,
        "warnings": warnings,
        "provenance": {
            "sentinel": "Contains modified Copernicus Sentinel data 2026.",
            "dem": "Produced using Copernicus WorldDEM-30 © DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.",
            "osm": "© OpenStreetMap contributors.",
            "sentinel_access": "Microsoft Planetary Computer STAC; Sentinel-1 RTC and Sentinel-2 L2A.",
            "validation": "EMSR927 reference layers are not queried or used as model inputs.",
        },
    }


def parse_event_date(value: str) -> date:
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise AnalysisError("Choose an event date in YYYY-MM-DD format.") from exc
    if parsed > date.today():
        raise AnalysisError("The event date must be today or earlier; post-event scenes are needed.")
    return parsed


def parse_bbox(value: Any) -> list[float]:
    try:
        bbox = [float(x) for x in value]
    except (TypeError, ValueError):
        raise AnalysisError("Enter the area as west, south, east, north coordinates.")
    if len(bbox) != 4 or not all(math.isfinite(x) for x in bbox):
        raise AnalysisError("The bounding box must contain four finite coordinates.")
    west, south, east, north = bbox
    if not (-180 <= west < east <= 180 and -85 <= south < north <= 85):
        raise AnalysisError("The bounding box coordinates are out of range or reversed.")
    # Approximate side lengths prevent accidental downloads of country-sized rasters.
    height_km = (north - south) * 111.2
    width_km = (east - west) * 111.2 * math.cos(math.radians((north + south) / 2))
    limit = float(os.getenv("MAX_AOI_KM", "25"))
    if max(width_km, height_km) > limit:
        raise AnalysisError(f"Each side of the analysis area must be at most {limit:g} km. Draw a smaller area and repeat.")
    if width_km < 0.4 or height_km < 0.4:
        raise AnalysisError("Choose an area at least 400 m wide and tall.")
    return bbox


def choose_osm_snapshot(event_date: date) -> datetime:
    event_end = datetime.combine(event_date, time(23, 59, 59), tzinfo=timezone.utc)
    requested = event_end - timedelta(days=1)
    return min(requested, OSM_MAX_SNAPSHOT)


def find_sentinel1_pair(catalog: Client, bbox: list[float], event_date: date):
    before_start = datetime.combine(event_date - timedelta(days=36), time.min, tzinfo=timezone.utc)
    after_end = datetime.combine(event_date + timedelta(days=36), time.max, tzinfo=timezone.utc)
    search = catalog.search(collections=["sentinel-1-rtc"], bbox=bbox,
                            datetime=f"{before_start.isoformat()}/{after_end.isoformat()}", limit=200)
    items = [item for item in search.items() if item.properties.get("sar:instrument_mode", "IW") == "IW"]
    event = datetime.combine(event_date, time.min, tzinfo=timezone.utc)
    before = [item for item in items if parse_item_datetime(item) < event]
    after = [item for item in items if parse_item_datetime(item) >= event]
    pairs = []
    for left in before:
        for right in after:
            orbit_left = item_orbit(left)
            orbit_right = item_orbit(right)
            dir_left = item_direction(left)
            dir_right = item_direction(right)
            if orbit_left != orbit_right or dir_left != dir_right:
                continue
            gap = abs((parse_item_datetime(right) - parse_item_datetime(left)).total_seconds() / 86400)
            days_left = (event - parse_item_datetime(left)).total_seconds() / 86400
            days_right = (parse_item_datetime(right) - event).total_seconds() / 86400
            track_penalty = 35 if orbit_left is None else 0
            score = abs(gap - 12) * 0.55 + days_left * 0.25 + days_right * 0.8 + track_penalty
            pairs.append((score, left, right, orbit_left, dir_left))
    if not pairs:
        raise AnalysisError("No Sentinel-1 before/after pair on a matching orbit was found within 36 days of this event date. Try a nearby date or a smaller AOI.")
    _, left, right, orbit, direction = min(pairs, key=lambda row: row[0])
    return left, right, orbit, direction


def find_sentinel2_pair(catalog: Client, bbox: list[float], event_date: date):
    before_start = datetime.combine(event_date - timedelta(days=45), time.min, tzinfo=timezone.utc)
    after_end = datetime.combine(event_date + timedelta(days=45), time.max, tzinfo=timezone.utc)
    search = catalog.search(collections=["sentinel-2-l2a"], bbox=bbox,
                            datetime=f"{before_start.isoformat()}/{after_end.isoformat()}", limit=200)
    items = [item for item in search.items()
             if float(item.properties.get("eo:cloud_cover", 100)
                      if item.properties.get("eo:cloud_cover") is not None else 100) <= 35]
    event = datetime.combine(event_date, time.min, tzinfo=timezone.utc)
    before = [item for item in items if parse_item_datetime(item) < event]
    after = [item for item in items if parse_item_datetime(item) >= event]
    if not before or not after:
        return None
    left = max(before, key=parse_item_datetime)
    right = min(after, key=parse_item_datetime)
    return left, right


def item_orbit(item) -> int | str | None:
    value = item.properties.get("sat:relative_orbit", item.properties.get("s1:relative_orbit"))
    return int(value) if value is not None else None


def item_direction(item) -> str | None:
    value = item.properties.get("sat:orbit_state", item.properties.get("sat:orbit_direction"))
    return str(value).lower() if value else None


def parse_item_datetime(item) -> datetime:
    value = item.datetime or item.properties.get("datetime")
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def item_date(item) -> str:
    return parse_item_datetime(item).date().isoformat()


def scene_summary(item) -> dict:
    return {"id": item.id, "date": item_date(item)}


def signed_asset(item, requested: str) -> str:
    wanted = requested.lower()
    for key, asset in item.assets.items():
        if key.lower() == wanted or asset.extra_fields.get("eo:bands", [{}])[0].get("name", "").lower() == wanted:
            return pc.sign(asset.href)
    raise AnalysisError(f"The selected satellite scene does not include the {requested.upper()} band needed for this analysis.")


def make_grid(bbox: list[float], crs) -> dict:
    west, south, east, north = bbox
    left, bottom, right, top = transform_bounds("EPSG:4326", crs, west, south, east, north, densify_pts=21)
    width_m, height_m = right - left, top - bottom
    resolution = RESOLUTION_M
    scale = max(1.0, math.sqrt((width_m * height_m) / (MAX_PIXELS * resolution ** 2)))
    resolution *= scale
    width = max(1, math.ceil(width_m / resolution))
    height = max(1, math.ceil(height_m / resolution))
    affine = from_origin(left, top, resolution, resolution)
    west, south, east, north = bbox
    boundary = Polygon([(west, south), (east, south), (east, north), (west, north), (west, south)])
    projected_boundary = reproject_geom(boundary, "EPSG:4326", crs)
    aoi_mask = geometry_mask([mapping(projected_boundary)], out_shape=(height, width),
                             transform=affine, invert=True)
    return {"crs": crs, "transform": affine, "width": width, "height": height,
            "resolution": resolution, "aoi_mask": aoi_mask}


def read_on_grid(dataset, grid: dict) -> np.ndarray:
    vrt = WarpedVRT(dataset, crs=grid["crs"], transform=grid["transform"],
                    width=grid["width"], height=grid["height"], dtype="float32",
                    nodata=np.nan, resampling=Resampling.bilinear)
    data = vrt.read(1, out_dtype="float32", masked=False)
    scale = dataset.scales[0] if dataset.scales else 1.0
    offset = dataset.offsets[0] if dataset.offsets else 0.0
    if scale != 1.0 or offset != 0.0:
        data = data * scale + offset
    if dataset.nodata is not None:
        data[data == dataset.nodata] = np.nan
    return data


def to_db(values: np.ndarray, dataset) -> np.ndarray:
    tags = " ".join(str(x).lower() for x in [dataset.tags(), dataset.tags(1)])
    unit = str(dataset.units[0]).lower() if dataset.units and dataset.units[0] else ""
    if "decibel" in tags or unit in {"db", "decibel", "decibels"} or np.nanmedian(values) < 0:
        return values
    # RTC backscatter may be delivered as linear power. Convert to dB for a stable threshold.
    return 10.0 * np.log10(np.maximum(values, 1e-7))


def read_dem(catalog: Client, bbox: list[float], grid: dict) -> np.ndarray | None:
    try:
        items = list(catalog.search(collections=["cop-dem-glo-30"], bbox=bbox, limit=20).items())
        if not items:
            return None
        item = items[0]
        for key in ("data", "dem", "elevation"):
            if key in item.assets:
                with rasterio.open(pc.sign(item.assets[key].href)) as src:
                    dem = read_on_grid(src, grid)
                if np.isfinite(dem).sum() > dem.size * 0.5:
                    return dem
        return None
    except Exception:
        return None


def slope_degrees(dem: np.ndarray, resolution: float) -> np.ndarray:
    safe = dem.copy()
    valid = np.isfinite(safe)
    if not valid.any():
        return np.full(dem.shape, np.nan)
    fill = float(np.nanmedian(safe))
    safe[~valid] = fill
    dy, dx = np.gradient(safe, resolution, resolution)
    slope = np.degrees(np.arctan(np.sqrt(dx * dx + dy * dy)))
    slope[~valid] = np.nan
    return slope


def polygonize_mask(mask: np.ndarray | None, grid: dict):
    if mask is None or not np.any(mask):
        return None
    polygons = []
    px_area = grid["resolution"] ** 2
    for geom, value in shapes(mask.astype("uint8"), mask=mask, transform=grid["transform"]):
        if value == 1:
            polygon = shape(geom)
            if polygon.area >= max(400.0, px_area * 2):
                polygons.append(polygon)
    if not polygons:
        return None
    return unary_union(polygons).simplify(grid["resolution"] * 0.75, preserve_topology=True)


def remove_small_components(mask: np.ndarray, min_pixels: int) -> np.ndarray:
    labels, count = ndimage.label(mask, structure=np.ones((3, 3), dtype="uint8"))
    if count == 0:
        return mask
    sizes = np.bincount(labels.ravel())
    keep = sizes >= min_pixels
    keep[0] = False
    return keep[labels]


def optical_water_gain(pair, grid: dict) -> np.ndarray:
    before_item, after_item = pair
    before_green = read_band(before_item, ("B03", "green"), grid)
    before_nir = read_band(before_item, ("B08", "nir"), grid)
    after_green = read_band(after_item, ("B03", "green"), grid)
    after_nir = read_band(after_item, ("B08", "nir"), grid)
    before_scl = read_band(before_item, ("SCL",), grid)
    after_scl = read_band(after_item, ("SCL",), grid)
    pre = (before_green - before_nir) / np.maximum(before_green + before_nir, 1e-6)
    post = (after_green - after_nir) / np.maximum(after_green + after_nir, 1e-6)
    cloud_and_invalid = (0, 1, 3, 8, 9, 10, 11)
    valid = (np.isfinite(pre) & np.isfinite(post) & grid["aoi_mask"]
             & ~np.isin(before_scl, cloud_and_invalid)
             & ~np.isin(after_scl, cloud_and_invalid))
    return valid & (post > 0.2) & (pre < 0.1)


def read_band(item, choices: tuple[str, ...], grid: dict) -> np.ndarray:
    asset = None
    for choice in choices:
        for key, value in item.assets.items():
            if key.lower() == choice.lower():
                asset = value
                break
        if asset:
            break
    if asset is None:
        raise AnalysisError(f"Sentinel-2 band {choices[0]} is not present in the selected scene.")
    with rasterio.open(pc.sign(asset.href)) as src:
        return read_on_grid(src, grid)


def ohsome_features(bbox: list[float], snapshot: datetime, filters: str) -> list[dict]:
    params = {
        "bboxes": ",".join(f"{value:.6f}" for value in bbox),
        "time": snapshot.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "filter": filters,
        "properties": "tags,metadata",
        "clipGeometry": "true",
    }
    headers = {}
    api_key = os.getenv("OHSOME_API_KEY", "").strip()
    if api_key:
        headers["Authorization"] = api_key
    try:
        response = requests.post(f"{OH_API}/elements/geometry", data=params, headers=headers, timeout=90)
        if response.status_code >= 400:
            detail = response.text[:250].replace("\n", " ")
            raise AnalysisError(f"ohsome could not return the pre-event OSM snapshot ({response.status_code}): {detail}")
        payload = response.json()
        return payload.get("features", [])
    except requests.RequestException as exc:
        raise AnalysisError(f"Could not reach the ohsome historical OSM service: {exc}") from exc


def load_osm_snapshot(bbox: list[float], snapshot: datetime) -> dict:
    context_bbox = expand_bbox(bbox, 5.0)
    roads = ohsome_features(context_bbox, snapshot, "highway=* and geometry:line")
    buildings = ohsome_features(context_bbox, snapshot, "building=* and geometry:polygon")
    bridges = ohsome_features(context_bbox, snapshot, "bridge=* and geometry:line")
    places = ohsome_features(context_bbox, snapshot, "place=* and geometry:point")
    places += ohsome_features(context_bbox, snapshot, "place=* and geometry:polygon")
    hospitals = ohsome_features(context_bbox, snapshot, "amenity=hospital and geometry:point")
    hospitals += ohsome_features(context_bbox, snapshot, "amenity=hospital and geometry:polygon")
    place_tags = {"city", "town", "village", "hamlet"}
    settlements = [f for f in places if get_tags(f).get("place") in place_tags]
    anchors = [f for f in places if get_tags(f).get("place") in {"city", "town"}]
    anchors += hospitals
    return {"roads": roads, "buildings": buildings, "bridges": bridges,
            "settlements": settlements, "anchors": anchors}


def expand_bbox(bbox: list[float], margin_km: float) -> list[float]:
    west, south, east, north = bbox
    lat_pad = margin_km / 111.2
    mid_lat = (south + north) / 2
    lon_pad = margin_km / max(20, 111.2 * math.cos(math.radians(mid_lat)))
    return [max(-180, west - lon_pad), max(-85, south - lat_pad),
            min(180, east + lon_pad), min(85, north + lat_pad)]


def get_tags(feature: dict) -> dict:
    props = feature.get("properties") or {}
    tags = props.get("tags")
    return tags if isinstance(tags, dict) else props


def normalize_feature(feature: dict, layer: str) -> dict | None:
    geom_data = feature.get("geometry")
    if not geom_data:
        return None
    props = feature.get("properties") or {}
    tags = get_tags(feature)
    osm_id = props.get("@osmId", props.get("osmId", props.get("@id", "")))
    keep = {k: tags[k] for k in ("name", "highway", "building", "bridge", "place", "amenity", "ref") if k in tags}
    keep.update({"osm_id": str(osm_id), "layer": layer})
    return {"type": "Feature", "geometry": geom_data, "properties": keep}


def feature_collection(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features}


def assess_assets(osm: dict, flood, bbox: list[float], flood_crs):
    # Use a local UTM projection for Nepal; for other longitudes use a computed UTM zone.
    center_lon = (bbox[0] + bbox[2]) / 2
    utm = utm_crs(center_lon, (bbox[1] + bbox[3]) / 2)
    projected_flood = reproject_geom(flood, flood_crs, utm) if flood is not None and not flood.is_empty else None
    buffer = projected_flood.buffer(10) if projected_flood is not None else None
    layers: dict[str, dict] = {}
    counts: dict[str, int] = {}
    from shapely.geometry import box
    aoi = box(bbox[0], bbox[1], bbox[2], bbox[3])
    for key, out_name in (("roads", "roads"), ("buildings", "buildings"), ("bridges", "bridges")):
        mapped = []
        hits = 0
        for feature in osm[key]:
            normalized = normalize_feature(feature, out_name)
            if normalized is None:
                continue
            geom = shape(feature["geometry"])
            intersects = bool(buffer and reproject_geom(geom, "EPSG:4326", utm).intersects(buffer))
            normalized["properties"]["intersects_flood_candidate"] = intersects
            if intersects:
                hits += 1
            clipped = geom.intersection(aoi)
            if not clipped.is_empty:
                normalized["geometry"] = mapping(clipped)
                mapped.append(normalized)
        layers[out_name] = feature_collection(mapped[:4000])
        counts[f"{out_name}_hit"] = hits
    # Buildings are polygons; map count is a count of mapped OSM features, not structures verified in field.
    return counts, layers, []


def assess_connectivity(roads: list[dict], settlements: list[dict], anchors: list[dict], flood, bbox: list[float], flood_crs):
    utm = utm_crs((bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2)
    graph_before = nx.Graph()
    graph_after = nx.Graph()
    node_coords: list[tuple[float, float]] = []
    projected_roads: list[tuple[dict, Any]] = []
    projected_flood = reproject_geom(flood, flood_crs, utm) if flood is not None and not flood.is_empty else None
    flooded = projected_flood.buffer(10) if projected_flood is not None and not projected_flood.is_empty else None
    for feature in roads:
        highway = get_tags(feature).get("highway", "")
        if highway in {"footway", "path", "cycleway", "steps", "pedestrian", "bridleway"}:
            continue
        try:
            geom = reproject_geom(shape(feature["geometry"]), "EPSG:4326", utm)
        except Exception:
            continue
        projected_roads.append((feature, geom))
        lines = [geom] if geom.geom_type == "LineString" else list(geom.geoms) if geom.geom_type == "MultiLineString" else []
        for line in lines:
            for a, b in pairwise(line.coords):
                segment = LineString([a, b])
                if segment.length > 2000:
                    # A sparse OSM way can skip a bend; subdivide long segments before the intersection test.
                    pieces = max(1, math.ceil(segment.length / 1000))
                    coords = [segment.interpolate(i / pieces, normalized=True).coords[0] for i in range(pieces + 1)]
                    subsegments = [LineString([coords[i], coords[i + 1]]) for i in range(pieces)]
                else:
                    subsegments = [segment]
                for part in subsegments:
                    u = (round(part.coords[0][0], 1), round(part.coords[0][1], 1))
                    v = (round(part.coords[-1][0], 1), round(part.coords[-1][1], 1))
                    graph_before.add_edge(u, v)
                    node_coords.append(u)
                    node_coords.append(v)
                    if flooded is None or not part.intersects(flooded):
                        graph_after.add_edge(u, v)
    unique_nodes = list(dict.fromkeys(node_coords))
    if not unique_nodes:
        return {"features": [], "warning": "No usable pre-event OSM roads were found; settlement connectivity could not be assessed."}
    anchor_points = []
    for feature in anchors:
        try:
            anchor_points.append(reproject_geom(shape(feature["geometry"]), "EPSG:4326", utm).representative_point())
        except Exception:
            continue
    anchor_nodes = set()
    for point in anchor_points:
        nearest = nearest_graph_node((point.x, point.y), unique_nodes)
        if nearest is not None and math.dist(nearest, (point.x, point.y)) <= 1000:
            anchor_nodes.add(nearest)
    if not anchor_nodes:
        return {"features": [], "warning": "No mapped town or hospital could be connected to the road graph; cut-off settlement counts are unavailable."}
    before_components = {node: i for i, comp in enumerate(nx.connected_components(graph_before)) for node in comp}
    after_components = {node: i for i, comp in enumerate(nx.connected_components(graph_after)) for node in comp}
    before_anchor_components = {before_components[n] for n in anchor_nodes if n in before_components}
    after_anchor_components = {after_components[n] for n in anchor_nodes if n in after_components}
    isolated = []
    for feature in settlements:
        geom = shape(feature["geometry"])
        center = geom.representative_point()
        if center.x < bbox[0] or center.x > bbox[2] or center.y < bbox[1] or center.y > bbox[3]:
            continue
        p = reproject_geom(geom, "EPSG:4326", utm).representative_point()
        node = nearest_graph_node((p.x, p.y), unique_nodes)
        if node is None or math.dist(node, (p.x, p.y)) > 1500:
            continue
        before_id, after_id = before_components.get(node), after_components.get(node)
        was_reachable = before_id in before_anchor_components
        now_reachable = after_id in after_anchor_components
        if was_reachable and not now_reachable:
            out = normalize_feature(feature, "isolated_settlement")
            if out:
                out["geometry"] = mapping(center)
                isolated.append(out)
    warning = "The connectivity screen only flags settlements connected to a mapped town or hospital before the flood mask removed intersecting road segments. It cannot confirm road passability."
    return {"features": isolated, "warning": warning}


def nearest_graph_node(point_xy: tuple[float, float], nodes: list[tuple[float, float]]):
    if not nodes:
        return None
    x, y = point_xy
    distances = [(node[0] - x) ** 2 + (node[1] - y) ** 2 for node in nodes]
    return nodes[int(np.argmin(distances))]


def reproject_geom(geom, source, target):
    transformer = Transformer.from_crs(source, target, always_xy=True)
    return transform_geometry(transformer.transform, geom)


def utm_crs(lon: float, lat: float) -> str:
    zone = max(1, min(60, int((lon + 180) // 6) + 1))
    return f"EPSG:{32600 + zone if lat >= 0 else 32700 + zone}"


def trace_downstream(upstream: Any, dem: np.ndarray, grid: dict, settlements: list[dict]):
    try:
        lon, lat = float(upstream[0]), float(upstream[1])
    except (TypeError, ValueError, IndexError):
        raise AnalysisError("Click a valid point inside the analysis map for the upstream trace.")
    transformer = Transformer.from_crs("EPSG:4326", grid["crs"], always_xy=True)
    x, y = transformer.transform(lon, lat)
    row, col = rasterio.transform.rowcol(grid["transform"], x, y)
    if not (0 <= row < dem.shape[0] and 0 <= col < dem.shape[1]) or not np.isfinite(dem[row, col]):
        raise AnalysisError("The selected upstream point is outside the DEM coverage.")
    cells = [(int(row), int(col))]
    visited = {cells[0]}
    for _ in range(3500):
        r, c = cells[-1]
        current = dem[r, c]
        best = (current, None)
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                nr, nc = r + dr, c + dc
                if 0 <= nr < dem.shape[0] and 0 <= nc < dem.shape[1] and (nr, nc) not in visited:
                    elevation = dem[nr, nc]
                    if np.isfinite(elevation) and elevation < best[0]:
                        best = (elevation, (nr, nc))
        if best[1] is None:
            break
        visited.add(best[1])
        cells.append(best[1])
    coords = [rasterio.transform.xy(grid["transform"], r, c, offset="center") for r, c in cells]
    if len(coords) < 2:
        raise AnalysisError("The elevation surface has no descending path from that point.")
    path_m = LineString(coords)
    geographic = reproject_geom(path_m, grid["crs"], "EPSG:4326")
    candidate_settlements = []
    for feature in settlements:
        point = reproject_geom(shape(feature["geometry"]), "EPSG:4326", grid["crs"]).representative_point()
        if path_m.distance(point) <= 750:
            tags = get_tags(feature)
            candidate_settlements.append(tags.get("name", "Unnamed settlement"))
    return {
        "distance_km": round(path_m.length / 1000, 1),
        "settlements_along_path": list(dict.fromkeys(candidate_settlements))[:30],
        "elevation_model": "Copernicus WorldDEM-30, routed on a 20 m resampled grid with a local D8 steepest-descent trace.",
        "feature": {"type": "Feature", "geometry": mapping(geographic), "properties": {"layer": "downstream_path"}},
    }


def build_sitrep(result: dict, language: str) -> str:
    s = result["summary"]
    if language == "ne":
        return (f"{result['area_name']} क्षेत्रमा {result['event_date']} का लागि प्रारम्भिक उपग्रह विश्लेषणले "
                f"{s['flood_ha']:.1f} हेक्टर बाढी सम्भावित क्षेत्र देखाउँछ। प्रि-इभेन्ट OSM नक्सामा "
                f"{s['buildings_hit']} भवन, {s['roads_hit']} सडक र {s['bridges_hit']} पुल उक्त क्षेत्रमा परे; "
                f"सडक-जडान परीक्षणले {s['settlements_cut_off']} बस्ती नयाँ रूपमा विच्छेद भएको देखायो। "
                f"यी प्रारम्भिक नक्सा-आधारित अनुमान हुन्, स्थलमा पुष्टि भएका क्षति होइनन्। उद्धार वा निकासीका लागि "
                f"एक्लै प्रयोग नगर्नुहोस्; फिल्ड टोलीबाट बाटो र संरचनाको अवस्था पुष्टि गर्नुहोस्।")
    return (f"Preliminary satellite analysis for {result['area_name']} on {result['event_date']} maps "
            f"{s['flood_ha']:.1f} ha of flood candidates. In the pre-event OSM snapshot, "
            f"{s['buildings_hit']} buildings, {s['roads_hit']} roads, and {s['bridges_hit']} bridges intersect "
            f"the candidate area; the road-graph screen flags {s['settlements_cut_off']} newly disconnected settlements. "
            "These are preliminary map-based estimates, not field-confirmed damage. Do not use this report alone "
            "to direct rescue or evacuation. Field teams should verify routes and structures.")
